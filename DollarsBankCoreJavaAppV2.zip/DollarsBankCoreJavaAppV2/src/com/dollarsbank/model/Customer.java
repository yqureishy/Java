package com.dollarsbank.model;


public class Customer {
	

}
