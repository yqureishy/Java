package com.dollarsbank.application;

import java.util.Scanner;

import com.dollarsbank.utility.ConsolePrinterUtility;

public class DollarsBankApplication {

	public static void main(String[] args) {
		
		ConsolePrinterUtility.mainMenu();
		
		Scanner sc = new Scanner(System.in);
		
		int option = sc.nextInt();

	}

}
